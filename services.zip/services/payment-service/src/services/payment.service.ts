import { prisma } from '@repo/database';
import { PaymentRepository } from '../repositories/payment.repository';
import { TransactionLedgerService } from './transaction-ledger.service';
import { CreatePaymentDTO, CreateEscrowPaymentDTO, XenditInvoiceCallback } from '../types';
import { xenditInvoiceClient } from '../config/xendit';
import { CreateInvoiceRequest } from 'xendit-node/invoice/models';
import axios from 'axios';

const WAREHOUSE_HANDLING_FEE = 5000;
const TRANSACTION_FEE_RATE = 0.02;

const notificationServiceUrl = process.env.NOTIFICATION_SERVICE_URL || 'http://localhost:3007';
const orderServiceUrl = process.env.ORDER_SERVICE_URL || 'http://localhost:3005';

export class PaymentService {
  private repository: PaymentRepository;
  private transactionLedgerService: TransactionLedgerService;

  constructor() {
    this.repository = new PaymentRepository();
    this.transactionLedgerService = new TransactionLedgerService();
  }

  async createPayment(data: CreatePaymentDTO) {
    const user = await prisma.users.findUnique({
      where: { id: data.userId },
      select: { id: true, email: true, phone_number: true, first_name: true, last_name: true,  user_wallets: true }
    });

    if (!user) {
      throw new Error('User not found');
    }

   // ✅ WORKAROUND: Make an internal API call to get order details
    let orderDetails;
    try {
      console.log(`Fetching details for order ${data.orderId} from Order Service...`);
      const response = await axios.get(`${orderServiceUrl}/api/orders/${data.orderId}`);
      orderDetails = response.data.data; // Assuming response is { success: true, data: order }
      if (!orderDetails) {
        throw new Error('Order data not found in response.');
      }
    } catch (error) {
      console.error('Failed to fetch order details from order-service:', error);
      throw new Error(`Could not retrieve order details for ID: ${data.orderId}`);
    }

    // ✅ Step 1: Calculate all fees using data from the API call
    const subtotal = Number(orderDetails.subtotal);
    const shippingCost = Number(orderDetails.shipping_cost || 0);
    const handlingFee = WAREHOUSE_HANDLING_FEE;
    const baseTotal = subtotal + shippingCost + handlingFee;
    const transactionFee = Math.ceil(baseTotal * TRANSACTION_FEE_RATE);
    const grandTotal = baseTotal + transactionFee;

    // ✅ Step 2: Wallet Payment Logic
    const walletBalance = Number(user.user_wallets?.balance || 0);
    let amountToPayViaXendit = grandTotal;
    let amountToPayViaWallet = 0;

    if (walletBalance > 0) {
      if (walletBalance >= grandTotal) {
        amountToPayViaWallet = grandTotal;
        amountToPayViaXendit = 0;
      } else {
        amountToPayViaWallet = walletBalance;
        amountToPayViaXendit = grandTotal - walletBalance;
      }
    }

    // Create the payment record in the database first
    const payment = await this.repository.create(data, '', '', {
      total_amount: grandTotal,
      payment_gateway_fee: transactionFee,
      metadata: { walletAmountUsed: amountToPayViaWallet } // Store wallet usage in metadata
    });

    // ✅ Step 3: Handle the payment flow
    if (amountToPayViaXendit > 0) {
      const userEmail = user.email || this.generatePlaceholderEmail(user.phone_number);
      const invoiceData: CreateInvoiceRequest = {
        externalId: `order-${data.orderId}-${Date.now()}`,
        amount: amountToPayViaXendit,
        payerEmail: userEmail,
        description: `Payment for order ${data.orderId}`,
        invoiceDuration: '86400',
        currency: 'IDR',
        shouldSendEmail: Boolean(user.email),
        customer: {
          givenNames: user.first_name,
          surname: user.last_name || '',
          email: userEmail,
          mobileNumber: user.phone_number
        },
        successRedirectUrl: process.env.PAYMENT_SUCCESS_URL,
        failureRedirectUrl: process.env.PAYMENT_FAILURE_URL
      };

      const invoice = await xenditInvoiceClient.createInvoice({ data: invoiceData });
      
      await prisma.payments.update({
        where: { id: payment.id },
        data: { payment_url: invoice.invoiceUrl, gateway_transaction_id: invoice.id }
      });
      
      const updatedPayment = await this.repository.findById(payment.id);
      return { payment: updatedPayment, paymentUrl: invoice.invoiceUrl, invoiceId: invoice.id };

    } else {
      // Full payment with wallet, no Xendit needed
      await this.handleFullWalletPayment(payment.id, user.id, amountToPayViaWallet, data.orderId);
      const paidPayment = await this.repository.findById(payment.id);
      return { payment: paidPayment, paymentUrl: null, invoiceId: null, message: 'Order paid in full with wallet.' };
    }
  }


  async handlePaidCallback(callbackData: XenditInvoiceCallback) {
    const payment = await this.repository.findByGatewayTransactionId(callbackData.id);
    if (!payment) throw new Error('Payment not found for transaction ID: ' + callbackData.id);
    if (payment.payment_status === 'paid') return { message: 'Payment already processed' };

    const isEscrowPayment = !payment.order_id && payment.is_in_escrow;
    const gatewayFee = callbackData.fees_paid_amount || 0;
    
    // For partial payments, debit the wallet amount that was stored in metadata
    const metadata = payment.metadata as any;
    const walletAmountUsed = Number(metadata?.walletAmountUsed || 0);

    if (walletAmountUsed > 0) {
      await this.debitWalletForPayment(payment.user_id, walletAmountUsed, payment.order_id || payment.id);
    }
    
    await this.repository.markPaid(payment.id, gatewayFee, callbackData, !!isEscrowPayment);
    
    if (payment.order_id) {
        await this.updateOrderStatus(payment.order_id, 'paid');
        await this.sendPaymentSuccessNotification(payment.user_id, payment.order_id, Number(payment.total_amount), payment.orders?.order_number || '');
    } else if (isEscrowPayment && payment.group_session_id) {
        await this.sendEscrowPaymentConfirmedNotification(payment.user_id, payment.group_session_id, Number(payment.total_amount));
    }

    return { message: 'Payment processed successfully', payment };
  }

   
  private async handleFullWalletPayment(paymentId: string, userId: string, amount: number, orderId: string) {
    await this.debitWalletForPayment(userId, amount, orderId);
    
    await prisma.payments.update({
      where: { id: paymentId },
      data: { 
        payment_status: 'paid', 
        paid_at: new Date(),
        gateway_transaction_id: `WALLET-${paymentId}`
      }
    });

    await this.updateOrderStatus(orderId, 'paid');
  }

  private async debitWalletForPayment(userId: string, amount: number, referenceId: string) {
    const wallet = await prisma.user_wallets.findUnique({ where: { user_id: userId } });
    if (!wallet || Number(wallet.balance) < amount) {
        console.error(`CRITICAL: Insufficient wallet balance for user ${userId}. Needed ${amount}, had ${wallet?.balance}.`);
        throw new Error('Insufficient wallet balance during payment processing.');
    }
    const balance_before = Number(wallet.balance);

    await prisma.$transaction([
      prisma.user_wallets.update({
        where: { user_id: userId },
        data: {
          balance: { decrement: amount },
          total_spent: { increment: amount }
        }
      }),
      prisma.wallet_transactions.create({
        data: {
          user_id: userId,
          amount: -amount,
          type: 'payment',
          description: `Payment for order/transaction ${referenceId}`,
          reference_id: referenceId,
          reference_type: 'order',
          balance_before: balance_before,
          balance_after: balance_before - amount
        }
      })
    ]);
  }

  private async updateOrderStatus(orderId: string, newStatus: string) {
    try {
      await axios.post(`${orderServiceUrl}/api/orders/status`, { orderId, newStatus });
      console.log(`✅ Successfully requested order status update for ${orderId} to ${newStatus}`);
    } catch (error) {
      console.error(`❌ CRITICAL: Failed to update status for order ${orderId}. Needs manual reconciliation.`, error);
    }
  }

  private async createXenditInvoice(user: any, referenceId: string, amount: number) {
    const userEmail = user.email || this.generatePlaceholderEmail(user.phone_number);
    const invoiceData: CreateInvoiceRequest = {
      externalId: `order-${referenceId}-${Date.now()}`, amount,
      payerEmail: userEmail,
      description: `Payment for order ${referenceId}`,
      invoiceDuration: '86400', currency: 'IDR',
      customer: { givenNames: user.first_name, surname: user.last_name || '', email: userEmail, mobileNumber: user.phone_number },
      successRedirectUrl: process.env.PAYMENT_SUCCESS_URL,
      failureRedirectUrl: process.env.PAYMENT_FAILURE_URL
    };
    return xenditInvoiceClient.createInvoice({ data: invoiceData });
  }




    async createEscrowPayment(data: CreatePaymentDTO & { groupSessionId: string; participantId: string }) {
    const user = await prisma.users.findUnique({
      where: { id: data.userId },
      select: { email: true, phone_number: true, first_name: true, last_name: true }
    });

    if (!user) {
      throw new Error('User not found');
    }

    const expiresAt = data.expiresAt ? new Date(data.expiresAt) : null;
    const userEmail = user.email || this.generatePlaceholderEmail(user.phone_number);

    const invoiceData: CreateInvoiceRequest = {
      externalId: `escrow-${data.groupSessionId}-${data.participantId}-${Date.now()}`,
      amount: data.amount,
      payerEmail: userEmail,
      description: `Escrow payment for group buying session`,
      invoiceDuration: expiresAt 
        ? Math.floor((expiresAt.getTime() - Date.now()) / 1000).toString()
        : '86400',
      currency: 'IDR',
      shouldSendEmail: Boolean(user.email),
      customer: {
        givenNames: user.first_name,
        surname: user.last_name || '',
        email: userEmail,
        mobileNumber: user.phone_number
      }
    };

    const invoice = await xenditInvoiceClient.createInvoice({ data: invoiceData });

    const payment = await prisma.payments.create({
      data: {
        user_id: data.userId,
        group_session_id: data.groupSessionId,
        participant_id: data.participantId,
        order_amount: data.amount,
        total_amount: data.amount, // Added required property
        payment_gateway_fee: 0,
        payment_status: 'pending',
        payment_method: 'bank_transfer',
        is_in_escrow: true,
        gateway_transaction_id: invoice.id || '',
        payment_url: invoice.invoiceUrl || '',
        expires_at: expiresAt
      }
    });

    return { payment, paymentUrl: invoice.invoiceUrl, invoiceId: invoice.id };
  }

  async releaseEscrow(groupSessionId: string) {
    const payments = await this.repository.findByGroupSession(groupSessionId);
    const eligiblePayments = payments.filter(
      p => p.is_in_escrow && p.payment_status === 'paid'
    );

    if (eligiblePayments.length === 0) {
      return { message: 'No escrowed payments found' };
    }

    const paymentIds = eligiblePayments.map(p => p.id);

    // Release escrow in database
    await this.repository.releaseEscrow(paymentIds);

    // Record transaction for each released payment
    for (const payment of eligiblePayments) {
      await this.transactionLedgerService.recordEscrowRelease(
        payment.id,
        payment.order_id ?? '',
        Number(payment.order_amount),
        groupSessionId
      );
    }
    const userIds = [...new Set(eligiblePayments.map(p => p.user_id))];
    if (userIds.length > 0) {
      await this.sendEscrowReleasedNotification(userIds, groupSessionId);
    }

    return {
      message: 'Escrow released',
      paymentsReleased: paymentIds.length
    };
  }

  async getPaymentByOrderId(orderId: string) {
    return this.repository.findByOrderId(orderId);
  }

  async findEligibleForSettlement(periodStart: Date, periodEnd: Date) {
    return this.repository.findEligibleForSettlement(periodStart, periodEnd);
  }

  /**
   * Get transaction history for an order (useful for customer support)
   */
  async getOrderTransactionHistory(orderId: string) {
    return this.transactionLedgerService.getOrderTransactionHistory(orderId);
  }

  /**
   * Get transaction history for a payment
   */
  async getPaymentTransactionHistory(paymentId: string) {
    return this.transactionLedgerService.getPaymentTransactionHistory(paymentId);
  }

   private async sendPaymentSuccessNotification(
    userId: string, 
    orderId: string,
    amount: number,
    orderNumber: string
  ) {
    try {
      // Get order details
      const order = await prisma.orders.findUnique({
        where: { id: orderId },
        include: {
          order_items: {
            take: 1,
            select: { product_name: true }
          }
        }
      });

      await axios.post(`${notificationServiceUrl}/api/notifications/send`, {
        recipientId: userId,
        type: 'payment_success',
        data: {
          amount: amount,
          productName: order?.order_items[0]?.product_name || 'Product',
          invoiceId: orderNumber,
          orderId: orderId
        },
        relatedId: orderId,
        channels: ['whatsapp']
      });

      console.log(`✅ Payment success notification sent to user ${userId}`);
    } catch (error) {
      console.error('❌ Failed to send payment success notification:', error);
      // Don't throw - notification failures shouldn't break payment flow
    }
  }

  /**
   * Send payment failed notification
   */
  private async sendPaymentFailedNotification(
    userId: string,
    orderId: string,
    reason?: string
  ) {
    try {
      const order = await prisma.orders.findUnique({
        where: { id: orderId },
        include: {
          order_items: {
            take: 1,
            select: { product_name: true }
          }
        }
      });

      await axios.post(`${notificationServiceUrl}/api/notifications/send`, {
        recipientId: userId,
        type: 'payment_failed',
        data: {
          productName: order?.order_items[0]?.product_name || 'Product',
          paymentId: orderId,
          reason: reason || 'Payment processing failed'
        },
        relatedId: orderId,
        channels: ['whatsapp']
      });

      console.log(`✅ Payment failed notification sent to user ${userId}`);
    } catch (error) {
      console.error('❌ Failed to send payment failed notification:', error);
    }
  }

  /**
   * Send escrow payment confirmed notification (for group buying)
   */
  private async sendEscrowPaymentConfirmedNotification(
    userId: string,
    groupSessionId: string,
    amount: number
  ) {
    try {
      const session = await prisma.group_buying_sessions.findUnique({
        where: { id: groupSessionId },
        include: {
          products: {
            select: { name: true }
          }
        }
      });

      await axios.post(`${notificationServiceUrl}/api/notifications/send`, {
        recipientId: userId,
        type: 'payment_success',
        data: {
          amount: amount,
          productName: session?.products?.name || 'Group Buying Product',
          invoiceId: session?.session_code || '',
          orderId: groupSessionId,
          isEscrow: true,
          message: 'Payment held in escrow until group is complete'
        },
        relatedId: groupSessionId,
        channels: ['whatsapp']
      });

      console.log(`✅ Escrow payment notification sent to user ${userId}`);
    } catch (error) {
      console.error('❌ Failed to send escrow payment notification:', error);
    }
  }

  /**
   * Send escrow released notification (bulk)
   */
  private async sendEscrowReleasedNotification(
    userIds: string[],
    groupSessionId: string
  ) {
    try {
      const session = await prisma.group_buying_sessions.findUnique({
        where: { id: groupSessionId },
        include: {
          products: {
            select: { name: true }
          }
        }
      });

      await axios.post(`${notificationServiceUrl}/api/notifications/send-bulk`, {
        recipients: userIds,
        type: 'production_completed',
        data: {
          sessionCode: session?.session_code || '',
          productName: session?.products?.name || 'Product',
          nextStep: 'Preparing for shipment'
        },
        relatedId: groupSessionId,
        channels: ['whatsapp']
      });

      console.log(`✅ Escrow released notification sent to ${userIds.length} users`);
    } catch (error) {
      console.error('❌ Failed to send escrow released notification:', error);
    }
  }
  private generatePlaceholderEmail(phoneNumber: string): string {
    const cleanPhone = phoneNumber.replace(/[^0-9+]/g, '');
    const domain = process.env.PLACEHOLDER_EMAIL_DOMAIN || 'pinduoduo.id';
    return `noreply+${cleanPhone}@${domain}`;
  }
}