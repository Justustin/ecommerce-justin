import { Request, Response } from 'express';
import { prisma } from '@repo/database';
import { PaymentService } from '../services/payment.service';
import { CryptoUtils } from '../utils/crypto.utils';
import axios from 'axios'; // ✅ ADD THIS

const notificationServiceUrl = process.env.NOTIFICATION_SERVICE_URL || 'http://localhost:3007'; // ✅ ADD THIS

export class WebhookController {
  private paymentService: PaymentService;

  constructor() {
    this.paymentService = new PaymentService();
  }

  handleXenditCallback = async (req: Request, res: Response) => {
    try {
      const callbackToken = process.env.XENDIT_CALLBACK_TOKEN || '';
      const receivedToken = req.headers['x-callback-token'] as string;
      console.log(`callbackToken: ${callbackToken}, receivedToken: ${receivedToken}`);

      if (!CryptoUtils.verifyXenditCallback(callbackToken, receivedToken)) {
        console.warn('Invalid callback token received');
        console.warn('Expected:', callbackToken);
        console.warn('Received:', receivedToken);
        return res.status(403).json({ error: 'Invalid callback token' });
      }

      const callbackData = req.body;
      const eventId = callbackData.id || callbackData.external_id;

      const existingEvent = await prisma.$queryRaw`
        SELECT * FROM webhook_events WHERE event_id = ${eventId}
      `;

      if (Array.isArray(existingEvent) && existingEvent.length > 0) {
        console.log(`Webhook event ${eventId} already processed - ignoring`);
        return res.json({ received: true, message: 'Already processed' });
      }

      await prisma.$executeRaw`
        INSERT INTO webhook_events (event_id, event_type, payload, processed)
        VALUES (${eventId}, ${callbackData.status || 'unknown'}, ${JSON.stringify(callbackData)}::jsonb, false)
      `;

      if (callbackData.status === 'PAID') {
        await this.paymentService.handlePaidCallback(callbackData);
        
        await prisma.$executeRaw`
          UPDATE webhook_events 
          SET processed = true, processed_at = NOW()
          WHERE event_id = ${eventId}
        `;
      } else if (callbackData.status === 'EXPIRED' || callbackData.status === 'FAILED') {
        const payment = await prisma.payments.findUnique({
          where: { gateway_transaction_id: callbackData.id },
          include: {
            orders: {
              include: {
                order_items: {
                  take: 1,
                  select: { product_name: true }
                }
              }
            }
          }
        });

        if (payment && payment.payment_status === 'pending') {
          await prisma.payments.update({
            where: { id: payment.id },
            data: {
              payment_status: callbackData.status === 'EXPIRED' ? 'expired' : 'failed',
              updated_at: new Date()
            }
          });

          if (payment.order_id) {
            await prisma.orders.update({
              where: { id: payment.order_id },
              data: {
                status: 'cancelled',
                cancelled_at: new Date(),
                updated_at: new Date()
              }
            });

            // ✅ NEW: Send payment failed notification
            try {
              await axios.post(`${notificationServiceUrl}/api/notifications/send`, {
                recipientId: payment.user_id,
                type: 'payment_failed',
                data: {
                  productName: payment.orders?.order_items[0]?.product_name || 'Product',
                  paymentId: payment.id,
                  orderId: payment.order_id,
                  reason: callbackData.status === 'EXPIRED' 
                    ? 'Payment link expired' 
                    : callbackData.failure_code || 'Payment failed'
                },
                relatedId: payment.order_id,
                channels: ['whatsapp']
              });

              console.log(`✅ Payment failed notification sent to user ${payment.user_id}`);
            } catch (notifError) {
              console.error('❌ Failed to send payment failed notification:', notifError);
            }
          }
        }

        await prisma.$executeRaw`
          UPDATE webhook_events 
          SET processed = true, processed_at = NOW()
          WHERE event_id = ${eventId}
        `;
      }

      res.json({ received: true });
    } catch (error: any) {
      console.error('Webhook error:', error);
      res.status(500).json({ error: error.message });
    }
  };
}