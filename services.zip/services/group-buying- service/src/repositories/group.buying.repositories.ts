import { prisma } from '@repo/database';
import {
  CreateGroupSessionDTO,
  UpdateGroupSessionDTO,
  GroupSessionFilters,
  PaginatedResponse
} from '../types';

export class GroupBuyingRepository {

  async createSession(data: CreateGroupSessionDTO) {
    return prisma.group_buying_sessions.create({
      data: {
        product_id: data.productId,
        factory_id: data.factoryId,
        session_code: data.sessionCode || this.generateSessionCode(),
        target_moq: data.targetMoq,
        group_price: data.basePrice,
        base_price: data.basePrice,
        tier_config: data.tierConfig as any,
        start_time: data.startTime || new Date(),
        end_time: data.endTime,
        estimated_completion_date: data.estimatedCompletionDate,
      }
    });
  }

  async updateSession(id: string, data: UpdateGroupSessionDTO) {
    const updateData: any = { updated_at: new Date() };

    if (data.endTime) updateData.end_time = data.endTime;
    if (data.targetMoq) updateData.target_moq = data.targetMoq;
    if (data.status) updateData.status = data.status;
    if (data.estimatedCompletionDate) updateData.estimated_completion_date = data.estimatedCompletionDate;
    if (data.basePrice) {
      updateData.base_price = data.basePrice;
      updateData.group_price = data.basePrice; // Keep them in sync
    }

    return prisma.group_buying_sessions.update({
      where: { id },
      data: updateData
    });
  }

  async findAll(filters: GroupSessionFilters): Promise<PaginatedResponse<any>> {
    const where: any = {};
    if (filters.status) where.status = filters.status;
    if (filters.factoryId) where.factory_id = filters.factoryId;
    if (filters.productId) where.product_id = filters.productId;
    if (filters.activeOnly) {
      where.end_time = { gt: new Date() };
      where.status = { in: ['forming', 'active'] };
    }
    if (filters.search) {
      where.OR = [
        { session_code: { contains: filters.search, mode: 'insensitive' } },
        { products: { name: { contains: filters.search, mode: 'insensitive' } } }
      ];
    }

    const page = filters.page || 1;
    const limit = filters.limit || 20;
    const skip = (page - 1) * limit;

    const [total, data] = await prisma.$transaction([
      prisma.group_buying_sessions.count({ where }),
      prisma.group_buying_sessions.findMany({
        where, skip, take: limit,
        include: {
          products: { select: { name: true, base_price: true, primary_image_url: true } },
          _count: { select: { group_participants: true } }
        },
        orderBy: { created_at: 'desc' }
      })
    ]);

    return { data, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } };
  }

  async findByIdWithDetails(id: string) {
    return prisma.group_buying_sessions.findUnique({
      where: { id },
      include: {
        products: { include: { factories: true, product_variants: true } },
        group_participants: { include: { users: { select: { id: true, first_name: true, last_name: true, avatar_url: true }} } }
      }
    });
  }

  async findProcessableExpiredSessions() {
    return prisma.group_buying_sessions.findMany({
      where: { end_time: { lte: new Date() }, status: 'forming' },
      include: {
        products: { include: { factories: true, product_variants: true } },
        group_participants: { where: { is_platform_order: false } }
      }
    });
  }

  async updateParticipantCashback(participantId: string, tierReached: number, cashbackAmount: number) {
      return prisma.group_participants.update({
          where: { id: participantId },
          data: { tier_reached: tierReached, cashback_amount: cashbackAmount }
      });
  }

  async finalizeSession(sessionId: string, tierReached: number, botQuantity: number, status: 'success' | 'failed') {
      return prisma.group_buying_sessions.update({
          where: { id: sessionId },
          data: { status, tier_reached: tierReached, platform_bot_quantity: botQuantity, finalized_at: new Date() }
      });
  }

  async getParticipantStats(sessionId: string) {
    const result = await prisma.group_participants.aggregate({
      where: { group_session_id: sessionId },
      _sum: { quantity: true },
      _count: { user_id: true }
    });
    return {
      totalQuantity: result._sum.quantity || 0,
      participantCount: result._count.user_id || 0
    };
  }

  async getSessionParticipants(sessionId: string) {
    return prisma.group_participants.findMany({
      where: { group_session_id: sessionId },
      include: {
        users: { select: { id: true, first_name: true, last_name: true, avatar_url: true } }
      },
      orderBy: { joined_at: 'asc' }
    });
  }
  
  async hasUserJoined(sessionId: string, userId: string): Promise<boolean> {
    const count = await prisma.group_participants.count({
      where: { group_session_id: sessionId, user_id: userId }
    });
    return count > 0;
  }
  
  private generateSessionCode(): string {
    const date = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const random = Math.random().toString(36).substring(2, 7).toUpperCase();
    return `GB-${date}-${random}`;
  }
   async createParticipant(data: {
    groupSessionId: string;
    userId: string;
    quantity: number;
    variantId?: string;
    unitPrice: number;
    totalPrice: number;
    shippingCost: number;
    isPlatformOrder?: boolean;
  }) {
    return prisma.group_participants.create({
      data: {
        // --- Mapping from camelCase (DTO) to snake_case (Schema) ---
        group_session_id: data.groupSessionId,
        user_id: data.userId,
        variant_id: data.variantId,
        unit_price: data.unitPrice,
        total_price: data.totalPrice,
        shipping_cost: data.shippingCost,
        is_platform_order: data.isPlatformOrder || false,
        // --- Fields that are the same ---
        quantity: data.quantity,
      }
    });
  }

}