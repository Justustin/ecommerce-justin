import { Router } from 'express';
import { body, param } from 'express-validator';
import { GroupBuyingController } from '../controllers/group-buying.controller';

const router = Router();
const controller = new GroupBuyingController();

// --- CORE LOGIC ROUTES ---

// POST /api/group-buying
router.post(
  '/',
  [
    body('productId').isUUID(),
    body('factoryId').isUUID(),
    body('targetMoq').isInt({ min: 2 }),
    body('basePrice').isFloat({ min: 1 }),
    body('tierConfig').isObject(),
    body('endTime').isISO8601().toDate(),
  ],
  controller.createSession
);

// POST /api/group-buying/calculate-shipping
router.post(
  '/calculate-shipping',
  [
    body('sessionId').isUUID(),
    body('quantity').isInt({ min: 1 }),
    body('destinationPostalCode').isString().notEmpty(),
  ],
  controller.calculateShipping
);

// POST /api/group-buying/:id/join
router.post(
  '/:id/join',
  [
    param('id').isUUID(),
    body('userId').isUUID(),
    body('quantity').isInt({ min: 1 }),
    // ✅ CORRECTED VALIDATION:
    // This chain now correctly handles cases where variantId is undefined, null, or a valid UUID.
    body('variantId').optional({ values: 'null' }).isUUID(),
    body('shippingAddress').isObject(),
    body('shippingAddress.postalCode').isString().notEmpty(),
  ],
  controller.joinSession
);

// POST /api/group-buying/process-expired
router.post('/process-expired', controller.processExpired);


// --- RESTORED CRUD & STATS ROUTES ---

// GET /api/group-buying
router.get('/', controller.listSessions);

// GET /api/group-buying/:id
router.get('/:id', [param('id').isUUID()], controller.getSessionById);

// PATCH /api/group-buying/:id
router.patch('/:id', [
    param('id').isUUID(),
    body('endTime').optional().isISO8601().toDate(),
    body('basePrice').optional().isFloat({ min: 1 }),
    body('targetMoq').optional().isInt({ min: 2 })
], controller.updateSession);

// GET /api/group-buying/:id/participants
router.get('/:id/participants', [param('id').isUUID()], controller.getParticipants);

// GET /api/group-buying/:id/stats
router.get('/:id/stats', [param('id').isUUID()], controller.getSessionStats);

export default router;