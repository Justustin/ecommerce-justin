import { group_status } from "@repo/database";

// Type for the tier configuration JSON object
export interface TierConfig {
  tiers: Array<{
    threshold: number; // e.g., 25, 50, 75, 100
    cashback: number;  // Cashback amount per item at this tier
  }>;
}

export interface CreateGroupSessionDTO {
  productId: string;
  factoryId: string;
  sessionCode?: string;
  targetMoq: number;
  basePrice: number;
  tierConfig: TierConfig;
  endTime: Date;
  startTime?: Date;
  estimatedCompletionDate?: Date;
}

export interface UpdateGroupSessionDTO {
  endTime?: Date;
  basePrice?: number;
  targetMoq?: number;
  status?: group_status;
  tierConfig?: TierConfig;
  estimatedCompletionDate?: Date | null;
}

// DTO for joining a session, now requires shipping address for calculation
export interface JoinGroupDTO {
  groupSessionId: string;
  userId: string;
  quantity: number;
  variantId?: string;
  shippingAddress: {
    postalCode: string;
  };
}

// DTO for the new shipping calculation endpoint
export interface CalculateShippingDTO {
    sessionId: string;
    quantity: number;
    destinationPostalCode: string;
}

export interface GroupSessionFilters {
  status?: 'forming' | 'active' | 'moq_reached' | 'success' | 'failed' | 'cancelled';
  factoryId?: string;
  productId?: string;
  activeOnly?: boolean;
  search?: string;
  page?: number;
  limit?: number;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}