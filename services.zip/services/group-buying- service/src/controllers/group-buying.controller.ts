import { Request, Response } from 'express';
import { validationResult } from 'express-validator';
import { GroupBuyingService } from '../services/group.buying.service';

export class GroupBuyingController {
  private service: GroupBuyingService;

  constructor() {
    this.service = new GroupBuyingService();
  }

  /**
   * Creates a new group buying session.
   * Corresponds to: POST /api/group-buying
   */
  createSession = async (req: Request, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const session = await this.service.createSession(req.body);
      res.status(201).json({
        message: 'Group buying session created successfully',
        data: session
      });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  };

  /**
   * Calculates the total two-leg shipping cost for a user before they join.
   * Corresponds to: POST /api/group-buying/calculate-shipping
   */
  calculateShipping = async (req: Request, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }
      const shippingCosts = await this.service.calculateShipping(req.body);
      res.status(200).json({
        message: 'Shipping costs calculated successfully',
        data: shippingCosts
      });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  };

  /**
   * Allows a user to join a session and creates the corresponding escrow payment.
   * Corresponds to: POST /api/group-buying/:id/join
   */
  joinSession = async (req: Request, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }
      
      const result = await this.service.joinSession({
        ...req.body,
        groupSessionId: req.params.id
      });

      res.status(201).json({
        message: 'Successfully joined session and initiated payment',
        data: result
      });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  };

  /**
   * Manually triggers the processing of expired sessions.
   * Corresponds to: POST /api/group-buying/process-expired
   */
  processExpired = async (req: Request, res: Response) => {
    try {
      // Intentionally not awaiting this so the request can return immediately
      // The processing will run in the background.
      this.service.processExpiredSessions();
      
      res.status(202).json({
        message: 'Expired sessions processing has been initiated in the background.'
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  };

  getSessionById = async (req: Request, res: Response) => {
    try {
      const session = await this.service.getSessionById(req.params.id);
      res.json({ success: true, data: session });
    } catch (error: any) {
      res.status(404).json({ success: false, error: error.message });
    }
  };

  listSessions = async (req: Request, res: Response) => {
    try {
      const result = await this.service.listSessions(req.query);
      res.json({ success: true, ...result });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message });
    }
  };

  updateSession = async (req: Request, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
      
      const session = await this.service.updateSession(req.params.id, req.body);
      res.json({ message: 'Session updated successfully', data: session });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  };

  getParticipants = async (req: Request, res: Response) => {
    try {
      const participants = await this.service.getParticipants(req.params.id);
      res.json({ success: true, data: participants });
    } catch (error: any) {
      res.status(404).json({ success: false, error: error.message });
    }
  };

  getSessionStats = async (req: Request, res: Response) => {
    try {
      const stats = await this.service.getSessionStats(req.params.id);
      res.json({ success: true, data: stats });
    } catch (error: any) {
      res.status(404).json({ success: false, error: error.message });
    }
  };
}