import { prisma } from '@repo/database';
import { GroupBuyingRepository } from '../repositories/group.buying.repositories';
import { CreateGroupSessionDTO, JoinGroupDTO, CalculateShippingDTO, TierConfig, GroupSessionFilters, UpdateGroupSessionDTO } from '../types';
import axios from 'axios';

// --- CONSTANTS AND URLS ---
const PLATFORM_BOT_USER_ID = '00000000-0000-0000-0000-000000000001';
const WAREHOUSE_POSTAL_CODE = '13910';
const MIN_MOQ_HELP_THRESHOLD = 0.25;

const LOGISTICS_SERVICE_URL = process.env.LOGISTICS_SERVICE_URL || 'http://localhost:3008';
const ORDER_SERVICE_URL = process.env.ORDER_SERVICE_URL || 'http://localhost:3005';
const PAYMENT_SERVICE_URL = process.env.PAYMENT_SERVICE_URL || 'http://localhost:3006';
const WAREHOUSE_SERVICE_URL = process.env.WAREHOUSE_SERVICE_URL || 'http://localhost:3009';
const WALLET_SERVICE_URL = process.env.WALLET_SERVICE_URL || 'http://localhost:3010';

export class GroupBuyingService {
    private repository: GroupBuyingRepository;

    constructor() {
        this.repository = new GroupBuyingRepository();
    }

    // --- CRUD & STATS METHODS ---

    async createSession(data: CreateGroupSessionDTO) {
        return this.repository.createSession(data);
    }

    async getSessionById(id: string) {
        const session = await this.repository.findByIdWithDetails(id); // ✅ CORRECTED
        if (!session) throw new Error('Session not found');
        return session;
    }

    async listSessions(filters: GroupSessionFilters) {
        return this.repository.findAll(filters);
    }
    
    async updateSession(id: string, data: UpdateGroupSessionDTO) {
        const session = await this.repository.findByIdWithDetails(id); // ✅ CORRECTED
        if (!session) throw new Error('Session not found');
        if (session.status !== 'forming') throw new Error('Only sessions in "forming" status can be updated.');
        return this.repository.updateSession(id, data);
    }

    async getParticipants(sessionId: string) {
        const session = await this.repository.findByIdWithDetails(sessionId); // ✅ CORRECTED
        if (!session) throw new Error('Session not found');
        return this.repository.getSessionParticipants(sessionId);
    }

    async getSessionStats(sessionId: string) {
        const [session, stats] = await Promise.all([
            this.repository.findByIdWithDetails(sessionId), // ✅ CORRECTED
            this.repository.getParticipantStats(sessionId)
        ]);
        if (!session) throw new Error('Session not found');
        
        const timeRemaining = new Date(session.end_time).getTime() - Date.now();
        const totalQuantity = stats.totalQuantity || 0;
        
        return {
            ...stats,
            targetMoq: session.target_moq,
            progress: totalQuantity > 0 ? (totalQuantity / session.target_moq) * 100 : 0,
            expired: timeRemaining <= 0,
            status: session.status
        };
    }

    async calculateShipping(data: CalculateShippingDTO) {
        const session = await this.repository.findByIdWithDetails(data.sessionId);
        if (!session) throw new Error('Session not found');

        const { products: product } = session;
        if (!product || !product.factories) throw new Error('Product or Factory details missing.');

        const factory = product.factories;

        const bulkRatePayload = {
            originPostalCode: factory.postal_code,
            destinationPostalCode: WAREHOUSE_POSTAL_CODE,
            items: [{
                name: product.name,
                value: Number(session.base_price) * session.target_moq,
                weight: (product.weight_grams || 500) * session.target_moq,
                quantity: 1
            }]
        };
        const bulkShippingCost = await this._getCheapestShippingRate(bulkRatePayload);
        const perItemLeg1Cost = Math.ceil(bulkShippingCost / session.target_moq);

        const individualRatePayload = {
            originPostalCode: WAREHOUSE_POSTAL_CODE,
            destinationPostalCode: data.destinationPostalCode,
            items: [{
                name: product.name,
                value: Number(session.base_price) * data.quantity,
                weight: (product.weight_grams || 500) * data.quantity,
                quantity: 1
            }]
        };
        const leg2Cost = await this._getCheapestShippingRate(individualRatePayload);

        const userLeg1Share = perItemLeg1Cost * data.quantity;
        const totalShippingCost = userLeg1Share + leg2Cost;

        return { totalShippingCost, leg1Cost: userLeg1Share, leg2Cost };
    }

    async joinSession(data: JoinGroupDTO) {
        const session = await this.repository.findByIdWithDetails(data.groupSessionId);
        if (!session) throw new Error('Session not found');
        if (session.status !== 'forming') throw new Error('Session is no longer accepting participants');
        if (await this.repository.hasUserJoined(session.id, data.userId)) throw new Error('User has already joined');

        const { totalShippingCost } = await this.calculateShipping({
            sessionId: data.groupSessionId,
            quantity: data.quantity,
            destinationPostalCode: data.shippingAddress.postalCode
        });

        const productTotal = Number(session.base_price) * data.quantity;
        const finalAmount = productTotal + totalShippingCost;

        const participant = await this.repository.createParticipant({
            ...data,
            unitPrice: Number(session.base_price),
            totalPrice: productTotal,
            shippingCost: totalShippingCost,
        });

        try {
            const paymentPayload = {
                userId: data.userId,
                groupSessionId: data.groupSessionId,
                participantId: participant.id,
                amount: finalAmount,
                factoryId: session.factory_id,
            };
            const response = await axios.post(`${PAYMENT_SERVICE_URL}/api/payments/escrow`, paymentPayload);
            return { participant, payment: response.data };
        } catch (error) {
            await prisma.group_participants.delete({ where: { id: participant.id } });
            console.error("Failed to create escrow payment:", error);
            throw new Error("Failed to process payment for session joining.");
        }
    }

async processExpiredSessions() {
        const expiredSessions = await this.repository.findProcessableExpiredSessions();
        console.log(`Found ${expiredSessions.length} sessions to process.`);

        for (const session of expiredSessions) {
            try {
                // ✅ FIX: Check if a bot participant ALREADY exists for this session.
                const botAlreadyExists = await this.repository.hasUserJoined(session.id, PLATFORM_BOT_USER_ID);
                if (botAlreadyExists) {
                    console.log(`Session ${session.id} has already been processed (bot exists). Skipping.`);
                    continue; // Skip to the next session
                }

                const totalRealQuantity = session.group_participants.reduce((sum, p) => sum + p.quantity, 0);
                let botQuantity = 0;
                const minThresholdQty = Math.ceil(session.target_moq * MIN_MOQ_HELP_THRESHOLD);

                if (totalRealQuantity < minThresholdQty) {
                    botQuantity = minThresholdQty - totalRealQuantity;
                    await this.repository.createParticipant({
                        groupSessionId: session.id,
                        userId: PLATFORM_BOT_USER_ID,
                        quantity: botQuantity,
                        unitPrice: Number(session.base_price),
                        totalPrice: Number(session.base_price) * botQuantity,
                        shippingCost: 0,
                        isPlatformOrder: true
                    });
                     console.log(`Bot added ${botQuantity} items to session ${session.session_code}.`);
                }
                
                const finalTotalQuantity = totalRealQuantity + botQuantity;
                if (finalTotalQuantity < minThresholdQty) {
                    await this.repository.finalizeSession(session.id, 0, 0, 'failed');
                    console.log(`Session ${session.session_code} failed with ${finalTotalQuantity}/${session.target_moq} items.`);
                    continue;
                }

                const tierConfig = session.tier_config as unknown as TierConfig;
                const tierPercentage = (finalTotalQuantity / session.target_moq) * 100;
                const bestTier = tierConfig.tiers.filter(t => tierPercentage >= t.threshold).pop() || { threshold: 0, cashback: 0 };
                
                for (const p of session.group_participants) {
                    const cashbackAmount = p.quantity * bestTier.cashback;
                    if (cashbackAmount > 0) {
                        await this._issueCashback(p.user_id, cashbackAmount, session.id);
                        await this.repository.updateParticipantCashback(p.id, bestTier.threshold, cashbackAmount);
                    }
                }
                
                await this._createBulkOrders(session.id);
                
                const wholesaleUnit = session.products?.factories?.wholesale_unit ?? 1;
                await this._notifyWarehouse(session.product_id, session.products.product_variants[0]?.id, finalTotalQuantity, wholesaleUnit);
                
                await this.repository.finalizeSession(session.id, bestTier.threshold, botQuantity, 'success');
                console.log(`Successfully processed session ${session.session_code}. Tier: ${bestTier.threshold}%`);
                
            } catch (error) {
                console.error(`Failed to process session ${session.id}:`, error);
            }
        }
    }
    

    private async _issueCashback(userId: string, amount: number, sessionId: string) {
        try {
            // This call is expected to fail for now
            await axios.post(`${WALLET_SERVICE_URL}/api/transactions/credit`, {
                userId, amount, type: 'cashback',
                description: `Cashback from group buying session ${sessionId}`
            });
            console.log(`Issued cashback of ${amount} to user ${userId}.`);
        } catch (error: any) {
            // ✅ FIX: Gracefully handle the expected error
            if (error.code === 'ECONNREFUSED') {
                console.warn(`Could not connect to Wallet Service at ${WALLET_SERVICE_URL}. Cashback for user ${userId} was not issued.`);
            } else {
                console.error(`Failed to issue cashback of ${amount} to user ${userId}:`, error);
            }
        }
    }

    private async _createBulkOrders(sessionId: string) {
        try {
            await axios.post(`${ORDER_SERVICE_URL}/api/orders/bulk-from-session`, { groupSessionId: sessionId });
        } catch (error: any) {
            console.error(`Failed to trigger bulk order creation for session ${sessionId}:`, error.message);
            throw new Error("Bulk order creation failed.");
        }
    }

    private async _notifyWarehouse(productId: string, variantId: string | undefined, quantity: number, wholesaleUnit: number) {
        try {
            await axios.post(`${WAREHOUSE_SERVICE_URL}/api/fulfill-demand`, {
                productId, variantId, quantity, wholesaleUnit
            });
        } catch (error: any) {
            // Gracefully handle this expected error
            if (error.code === 'ECONNREFUSED') {
                console.warn(`Could not connect to Warehouse Service at ${WAREHOUSE_SERVICE_URL}. Demand was not fulfilled.`);
            } else {
                console.error(`Failed to notify warehouse for product ${productId}:`, error);
                throw new Error("Warehouse notification failed.");
            }
        }
    }

    // --- Private Helper Methods ---

    private async _getCheapestShippingRate(payload: any): Promise<number> {
        try {
            const response = await axios.post(`${LOGISTICS_SERVICE_URL}/api/rates`, payload);
            const rates = response.data.data?.pricing || [];
            if (rates.length === 0) return 15000; // Fallback cost
            return rates[0].price;
        } catch (error) {
            console.error("Logistics service error:", error);
            return 15000; // Fallback cost on error
        }
    }

  }



