// src/types/index.ts
import { notification_type } from '@repo/database';
export type NotificationType = notification_type;
export const NotificationType = {
  // Payment
  PAYMENT_SUCCESS: 'payment_success' as notification_type,
  PAYMENT_FAILED: 'payment_failed' as notification_type,
  
  // Group Buying
  MOQ_REACHED: 'moq_reached' as notification_type,
  GROUP_CONFIRMED: 'group_confirmed' as notification_type,
  GROUP_FAILED: 'group_failed' as notification_type,
  GROUP_EXPIRING: 'group_expiring' as notification_type,
  
  // Production
  PRODUCTION_STARTED: 'production_started' as notification_type,
  PRODUCTION_COMPLETED: 'production_completed' as notification_type,
  
  // Orders & Shipping
  ORDER_CREATED: 'order_created' as notification_type,
  READY_FOR_PICKUP: 'ready_for_pickup' as notification_type,
  PICKED_UP: 'picked_up' as notification_type,
  SHIPPED: 'shipped' as notification_type,
  OUT_FOR_DELIVERY: 'out_for_delivery' as notification_type,
  DELIVERED: 'delivered' as notification_type,
  
  // Reviews & Refunds
  REVIEW_REMINDER: 'review_reminder' as notification_type,
  REFUND_INITIATED: 'refund_initiated' as notification_type,
  REFUND_COMPLETED: 'refund_completed' as notification_type,
  
  // Other
  ORDER_CANCELLED: 'order_cancelled' as notification_type,
};

export type NotificationChannel = 'push' | 'whatsapp';

export interface SendNotificationDTO {
  recipientId: string;
  type: NotificationType;
  data: Record<string, any>;
  relatedId?: string;
  channels?: NotificationChannel[];
}

export interface SendBulkNotificationDTO {
  recipients: string[];
  type: NotificationType;
  data: Record<string, any>;
  relatedId?: string;
  channels?: NotificationChannel[];
}

export interface CreateNotificationDTO {
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  actionUrl?: string;
  relatedId?: string;
  channels?: NotificationChannel[];
}

export interface NotificationTemplate {
  title: string;
  message: string;
  whatsappMessage: string;
  actionUrl?: string;
  icon?: string;
  badge?: string;
}

export interface PushSubscription {
  userId: string;
  endpoint: string;
  keys: {
    p256dh: string;
    auth: string;
  };
}

export interface RegisterPushSubscriptionDTO {
  userId: string;
  subscription: {
    endpoint: string;
    keys: {
      p256dh: string;
      auth: string;
    };
  };
}

export interface NotificationFilters {
  userId?: string;
  type?: NotificationType;
  isRead?: boolean;
  page?: number;
  limit?: number;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export interface UserResponseDTO {
  userId: string;
  phoneNumber: string;
  firstName: string;
  lastName: string;
  role: string;
}

export interface BulkUsersRequestDTO {
  userIds: string[];
}

export interface BulkUsersResponseDTO {
  users: UserResponseDTO[];
}