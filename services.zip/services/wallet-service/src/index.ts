import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import walletRoutes from './routes/wallet.routes';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3010;

app.use(cors());
app.use(express.json());

// Main application routes
app.use('/api', walletRoutes);

app.get('/', (req, res) => {
    res.send('Wallet Service is running!');
});

app.listen(PORT, () => {
    console.log(`🚀 Wallet Service listening on port ${PORT}`);
});