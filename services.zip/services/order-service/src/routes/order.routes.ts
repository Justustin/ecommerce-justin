// services/order-service/src/routes/order.routes.ts

import { Router } from 'express';
import { body, param } from 'express-validator';
import { OrderController } from '../controllers/order.controller';

const router = Router();
const controller = new OrderController();

/**
 * @swagger
 * /api/orders:
 *   post:
 *     summary: Create new order(s) - splits by factory if multi-vendor cart
 *     tags: [Orders]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [userId, items, shippingAddress]
 *             properties:
 *               userId:
 *                 type: string
 *                 format: uuid
 *                 example: a1b2c3d4-e5f6-7890-abcd-ef1234567890
 *               groupSessionId:
 *                 type: string
 *                 format: uuid
 *                 description: Optional - for group buying orders
 *               items:
 *                 type: array
 *                 minItems: 1
 *                 items:
 *                   type: object
 *                   required: [productId, quantity]
 *                   properties:
 *                     productId:
 *                       type: string
 *                       format: uuid
 *                     variantId:
 *                       type: string
 *                       format: uuid
 *                     quantity:
 *                       type: integer
 *                       minimum: 1
 *                       example: 2
 *               shippingAddress:
 *                 type: object
 *                 required: [name, phone, province, city, district, address]
 *                 properties:
 *                   name:
 *                     type: string
 *                     example: John Doe
 *                   phone:
 *                     type: string
 *                     example: "081234567890"
 *                   province:
 *                     type: string
 *                     example: DKI Jakarta
 *                   city:
 *                     type: string
 *                     example: Jakarta Pusat
 *                   district:
 *                     type: string
 *                     example: Menteng
 *                   postalCode:
 *                     type: string
 *                     example: "10310"
 *                   address:
 *                     type: string
 *                     example: Jl. Sudirman No. 123
 *               shippingNotes:
 *                 type: string
 *                 example: Please call before delivery
 *               discountAmount:
 *                 type: number
 *                 example: 10000
 *     responses:
 *       201:
 *         description: Order(s) created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 ordersCreated:
 *                   type: integer
 *                   example: 2
 *                 message:
 *                   type: string
 *                   example: Created 2 orders (items from 2 factories)
 *                 orders:
 *                   type: array
 *                   items:
 *                     type: object
 *       400:
 *         description: Bad request
 */
router.post('/', [
  body('userId').isUUID(),
  body('items').isArray({ min: 1 }),
  body('items.*.productId').isUUID(),
  body('items.*.quantity').isInt({ min: 1 }),
  body('shippingAddress.name').notEmpty(),
  body('shippingAddress.phone').notEmpty(),
  body('shippingAddress.address').notEmpty(),
  body('shippingAddress.city').notEmpty(),
  body('shippingAddress.province').notEmpty(),
  body('shippingAddress.district').notEmpty()
], controller.createOrder);
/**
 * @swagger
 * /api/orders/bulk-from-session:  <-- CORRECTED PATH
 *   post:
 *     summary: Create bulk orders from group session (internal use by group-buying-service)
 *     tags: [Orders]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [groupSessionId]
 *             properties:
 *               groupSessionId:
 *                 type: string
 *                 format: uuid
 *     responses:
 *       201:
 *         description: Bulk orders created successfully
 *       400:
 *         description: Bad request
 */
router.post('/bulk-from-session', [ // <-- CORRECTED PATH
  body('groupSessionId').isUUID(),
  // The 'participants' array is not sent in the new logic, so we remove this validation
], controller.createBulkOrders);

/**
 * @swagger
 * /api/orders:
 *   get:
 *     summary: Get all orders with filters
 *     tags: [Orders]
 *     parameters:
 *       - in: query
 *         name: userId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by user ID
 *       - in: query
 *         name: factoryId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by factory ID
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [pending_payment, paid, processing, ready_for_pickup, picked_up, in_transit, delivered, cancelled, refunded, failed]
 *         description: Filter by order status
 *       - in: query
 *         name: isGroupBuying
 *         schema:
 *           type: boolean
 *         description: Filter group buying orders (true) or direct orders (false)
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Search by order number or recipient name
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Page number
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *         description: Items per page
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Filter orders from this date
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Filter orders until this date
 *     responses:
 *       200:
 *         description: List of orders with pagination
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                 pagination:
 *                   type: object
 *                   properties:
 *                     page:
 *                       type: integer
 *                     limit:
 *                       type: integer
 *                     total:
 *                       type: integer
 *                     totalPages:
 *                       type: integer
 */
router.get('/', controller.getOrders);

/**
 * @swagger
 * /api/orders/stats:
 *   get:
 *     summary: Get order statistics
 *     tags: [Orders]
 *     parameters:
 *       - in: query
 *         name: userId
 *         schema:
 *           type: string
 *           format: uuid
 *       - in: query
 *         name: factoryId
 *         schema:
 *           type: string
 *           format: uuid
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date
 *     responses:
 *       200:
 *         description: Order statistics
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     totalOrders:
 *                       type: integer
 *                     totalRevenue:
 *                       type: number
 *                     averageOrderValue:
 *                       type: number
 *                     ordersByStatus:
 *                       type: object
 */
router.get('/stats', controller.getOrderStats);

/**
 * @swagger
 * /api/orders/user/{userId}:
 *   get:
 *     summary: Get all orders for a specific user
 *     tags: [Orders]
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *     responses:
 *       200:
 *         description: User's orders with pagination
 */
router.get('/user/:userId', [
  param('userId').isUUID()
], controller.getUserOrders);

/**
 * @swagger
 * /api/orders/factory/{factoryId}:
 *   get:
 *     summary: Get all orders for a specific factory
 *     tags: [Orders]
 *     parameters:
 *       - in: path
 *         name: factoryId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *     responses:
 *       200:
 *         description: Factory's orders with pagination
 */
router.get('/factory/:factoryId', [
  param('factoryId').isUUID()
], controller.getFactoryOrders);

/**
 * @swagger
 * /api/orders/number/{orderNumber}:
 *   get:
 *     summary: Get order by order number
 *     tags: [Orders]
 *     parameters:
 *       - in: path
 *         name: orderNumber
 *         required: true
 *         schema:
 *           type: string
 *         example: ORD-20251005-A7B3C
 *     responses:
 *       200:
 *         description: Order details
 *       404:
 *         description: Order not found
 */
router.get('/number/:orderNumber', controller.getOrderByNumber);

/**
 * @swagger
 * /api/orders/{id}:
 *   get:
 *     summary: Get order by ID
 *     tags: [Orders]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Order details with items, user, and factory info
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *       404:
 *         description: Order not found
 */
router.get('/:id', [
  param('id').isUUID()
], controller.getOrder);

/**
 * @swagger
 * /api/orders/{id}/status:
 *   put:
 *     summary: Update order status
 *     tags: [Orders]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [newStatus]
 *             properties:
 *               newStatus:
 *                 type: string
 *                 enum: [pending_payment, paid, processing, ready_for_pickup, picked_up, in_transit, delivered, cancelled, refunded, failed]
 *                 example: paid
 *               estimatedDeliveryDate:
 *                 type: string
 *                 format: date
 *                 example: "2025-10-10"
 *     responses:
 *       200:
 *         description: Order status updated
 *       400:
 *         description: Invalid status transition
 */
router.put('/:id/status', [
  param('id').isUUID(),
  body('newStatus').isIn([
    'pending_payment', 'paid', 'processing', 'ready_for_pickup',
    'picked_up', 'in_transit', 'delivered', 'cancelled',
    'refunded', 'failed'
  ])
], controller.updateOrderStatus);

/**
 * @swagger
 * /api/orders/{id}/shipping-cost:
 *   put:
 *     summary: Update shipping cost and tax
 *     tags: [Orders]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [shippingCost]
 *             properties:
 *               shippingCost:
 *                 type: number
 *                 minimum: 0
 *                 example: 15000
 *               taxAmount:
 *                 type: number
 *                 minimum: 0
 *                 example: 5000
 *     responses:
 *       200:
 *         description: Shipping cost updated
 *       400:
 *         description: Bad request
 */
router.put('/:id/shipping-cost', [
  param('id').isUUID(),
  body('shippingCost').isFloat({ min: 0 })
], controller.updateShippingCost);

/**
 * @swagger
 * /api/orders/{id}/cancel:
 *   post:
 *     summary: Cancel an order
 *     tags: [Orders]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               userId:
 *                 type: string
 *                 format: uuid
 *                 description: User ID for authorization
 *     responses:
 *       200:
 *         description: Order cancelled successfully
 *       400:
 *         description: Cannot cancel order in current status
 */
router.post('/:id/cancel', [
  param('id').isUUID()
], controller.cancelOrder);

/**
 * @swagger
 * /api/orders/calculate-shipping:
 *   post:
 *     summary: Calculate shipping rates for checkout
 *     tags: [Orders]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [destinationPostalCode]
 *             properties:
 *               orderId:
 *                 type: string
 *                 format: uuid
 *                 description: Optional - For existing order
 *                 example: a1b2c3d4-e5f6-7890-abcd-ef1234567890
 *               destinationPostalCode:
 *                 type: string
 *                 example: "12190"
 *                 description: Destination postal code (5 digits)
 *               items:
 *                 type: array
 *                 description: Optional - Products for rate calculation (if no orderId)
 *                 items:
 *                   type: object
 *                   properties:
 *                     productId:
 *                       type: string
 *                       format: uuid
 *                       example: 9d0280b8-fb12-48c9-8727-4f1572b5fe40
 *                     quantity:
 *                       type: integer
 *                       minimum: 1
 *                       example: 2
 *     responses:
 *       200:
 *         description: Shipping rates from multiple couriers
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       courier_name:
 *                         type: string
 *                         example: "J&T"
 *                       courier_code:
 *                         type: string
 *                         example: "jnt"
 *                       courier_service_name:
 *                         type: string
 *                         example: "EZ"
 *                       courier_service_code:
 *                         type: string
 *                         example: "ez"
 *                       price:
 *                         type: number
 *                         example: 14000
 *                       duration:
 *                         type: string
 *                         example: "2 - 3 days"
 *                       description:
 *                         type: string
 *                         example: "Layanan reguler"
 *                       available_for_cash_on_delivery:
 *                         type: boolean
 *                         example: false
 *       400:
 *         description: Bad request - Missing postal code
 */
router.post('/calculate-shipping', [
  body('destinationPostalCode').notEmpty()
], controller.calculateShippingRates);

/**
 * @swagger
 * /api/orders/status-callback:
 *   post:
 *     summary: Update order status from logistics service (webhook)
 *     tags: [Orders]
 *     description: Internal endpoint called by logistics service when shipment status changes
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [orderId, newStatus]
 *             properties:
 *               orderId:
 *                 type: string
 *                 format: uuid
 *                 example: a1b2c3d4-e5f6-7890-abcd-ef1234567890
 *               newStatus:
 *                 type: string
 *                 enum: [picked_up, in_transit, delivered, failed]
 *                 example: "picked_up"
 *                 description: New status from logistics provider
 *     responses:
 *       200:
 *         description: Order status updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Order status updated to picked_up"
 *       400:
 *         description: Invalid request
 *       404:
 *         description: Order not found
 */
router.post('/status-callback', [
  body('orderId').isUUID(),
  body('newStatus').notEmpty()
], controller.updateOrderStatusFromLogistics);

/**
 * @swagger
 * /api/orders/{id}/tracking:
 *   get:
 *     summary: Get shipment tracking information for an order
 *     tags: [Orders]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Order ID
 *         example: a1b2c3d4-e5f6-7890-abcd-ef1234567890
 *     responses:
 *       200:
 *         description: Tracking information with shipment details and events
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: object
 *                   properties:
 *                     success:
 *                       type: boolean
 *                     data:
 *                       type: object
 *                       properties:
 *                         id:
 *                           type: string
 *                           format: uuid
 *                         tracking_number:
 *                           type: string
 *                           example: "WYB-1760424083492"
 *                         courier_service:
 *                           type: string
 *                           example: "jnt"
 *                         service_type:
 *                           type: string
 *                           example: "ez"
 *                         status:
 *                           type: string
 *                           example: "pending"
 *                         sender_name:
 *                           type: string
 *                           example: "Batik Pekalongan Premium Team"
 *                         recipient_name:
 *                           type: string
 *                           example: "John Doe"
 *                         shipping_cost:
 *                           type: string
 *                           example: "14000"
 *                         shipment_tracking_events:
 *                           type: array
 *                           items:
 *                             type: object
 *                             properties:
 *                               id:
 *                                 type: string
 *                                 format: uuid
 *                               status:
 *                                 type: string
 *                                 example: "pending"
 *                               description:
 *                                 type: string
 *                                 example: "Shipment created and awaiting pickup"
 *                               location:
 *                                 type: string
 *                                 example: "Jl. Batik Raya No. 123"
 *                               event_time:
 *                                 type: string
 *                                 format: date-time
 *       404:
 *         description: Order not found or no shipment exists
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: null
 *                   example: null
 *       500:
 *         description: Server error
 */
router.get('/:id/tracking', [
  param('id').isUUID()
], controller.getOrderTracking);

/**
 * @swagger
 * /api/orders/{id}/create-shipment:
 *   post:
 *     summary: Manually create shipment for an order
 *     tags: [Orders]
 *     description: Create shipment with selected courier. Normally auto-triggered when order status becomes ready_for_pickup
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Order ID
 *         example: a1b2c3d4-e5f6-7890-abcd-ef1234567890
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [courierCompany, courierType]
 *             properties:
 *               courierCompany:
 *                 type: string
 *                 enum: [jne, jnt, sicepat, anteraja, gojek]
 *                 example: "jnt"
 *                 description: Courier company code
 *               courierType:
 *                 type: string
 *                 example: "ez"
 *                 description: Service type code (e.g., reg, ez, yes, best)
 *     responses:
 *       200:
 *         description: Shipment created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: object
 *                   properties:
 *                     shipment:
 *                       type: object
 *                       properties:
 *                         id:
 *                           type: string
 *                           format: uuid
 *                         tracking_number:
 *                           type: string
 *                           example: "WYB-1760424083492"
 *                         courier_service:
 *                           type: string
 *                           example: "jnt"
 *                         status:
 *                           type: string
 *                           example: "pending"
 *                     trackingUrl:
 *                       type: string
 *                       example: "https://track.biteship.com/..."
 *       400:
 *         description: Bad request - Order not ready or shipment already exists
 *       404:
 *         description: Order not found
 *       500:
 *         description: Failed to create shipment
 */
router.post('/:id/create-shipment', [
  param('id').isUUID()
], controller.createShipment);

export default router;