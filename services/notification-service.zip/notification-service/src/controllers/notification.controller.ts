// src/controllers/notification.controller.ts
import { Request, Response } from 'express';
import { NotificationService } from '../services/notification.service';
import { SendNotificationDTO, SendBulkNotificationDTO, NotificationFilters } from '../types';

export class NotificationController {
  private service: NotificationService;

  constructor() {
    this.service = new NotificationService();
  }

  /**
   * Send notification to a single user
   * POST /api/notifications/send
   */
  sendNotification = async (req: Request, res: Response) => {
    try {
      const data: SendNotificationDTO = req.body;

      // Validate required fields
      if (!data.recipientId || !data.type || !data.data) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: recipientId, type, data'
        });
      }

      await this.service.send(data);

      res.status(200).json({
        success: true,
        message: 'Notification sent successfully'
      });
    } catch (error: any) {
      console.error('Send notification error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to send notification',
        error: error.message
      });
    }
  };

  /**
   * Send bulk notifications
   * POST /api/notifications/send-bulk
   */
  sendBulkNotification = async (req: Request, res: Response) => {
    try {
      const data: SendBulkNotificationDTO = req.body;

      if (!data.recipients || !Array.isArray(data.recipients) || data.recipients.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'Recipients array is required and must not be empty'
        });
      }

      if (!data.type || !data.data) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: type, data'
        });
      }

      await this.service.sendBulk(data);

      res.status(200).json({
        success: true,
        message: `Bulk notification sent to ${data.recipients.length} users`
      });
    } catch (error: any) {
      console.error('Send bulk notification error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to send bulk notification',
        error: error.message
      });
    }
  };

  /**
   * Get user notifications with pagination
   * GET /api/notifications
   */
  getNotifications = async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId as string || (req as any).user?.id;
      const type = req.query.type as string;
      const isRead = req.query.isRead === 'true' ? true : req.query.isRead === 'false' ? false : undefined;
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;

      if (!userId) {
        return res.status(400).json({
          success: false,
          message: 'userId is required'
        });
      }

      const filters: NotificationFilters = {
        userId,
        type: type as any,
        isRead,
        page,
        limit
      };

      const result = await this.service.getUserNotifications(filters);

      res.status(200).json({
        success: true,
        data: result.data,
        pagination: result.pagination
      });
    } catch (error: any) {
      console.error('Get notifications error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to retrieve notifications',
        error: error.message
      });
    }
  };

  /**
   * Get unread notifications
   * GET /api/notifications/unread
   */
  getUnreadNotifications = async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId as string || (req as any).user?.id;

      if (!userId) {
        return res.status(400).json({
          success: false,
          message: 'userId is required'
        });
      }

      const notifications = await this.service.getUnreadNotifications(userId);

      res.status(200).json({
        success: true,
        data: notifications
      });
    } catch (error: any) {
      console.error('Get unread notifications error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to retrieve unread notifications',
        error: error.message
      });
    }
  };

  /**
   * Get unread count
   * GET /api/notifications/unread-count
   */
  getUnreadCount = async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId as string || (req as any).user?.id;

      if (!userId) {
        return res.status(400).json({
          success: false,
          message: 'userId is required'
        });
      }

      const result = await this.service.getUnreadCount(userId);

      res.status(200).json({
        success: true,
        data: result
      });
    } catch (error: any) {
      console.error('Get unread count error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to retrieve unread count',
        error: error.message
      });
    }
  };

  /**
   * Mark notification as read
   * PATCH /api/notifications/:id/read
   */
  markAsRead = async (req: Request, res: Response) => {
    try {
      const notificationId = req.params.id;
      const userId = req.body.userId || (req as any).user?.id;

      if (!userId) {
        return res.status(400).json({
          success: false,
          message: 'userId is required'
        });
      }

      const result = await this.service.markAsRead(notificationId, userId);

      res.status(200).json({
        success: true,
        message: result.message
      });
    } catch (error: any) {
      console.error('Mark as read error:', error);
      res.status(error.message.includes('not found') ? 404 : 500).json({
        success: false,
        message: error.message
      });
    }
  };

  /**
   * Mark all notifications as read
   * PATCH /api/notifications/read-all
   */
  markAllAsRead = async (req: Request, res: Response) => {
    try {
      const userId = req.body.userId || (req as any).user?.id;

      if (!userId) {
        return res.status(400).json({
          success: false,
          message: 'userId is required'
        });
      }

      const result = await this.service.markAllAsRead(userId);

      res.status(200).json({
        success: true,
        message: result.message,
        count: result.count
      });
    } catch (error: any) {
      console.error('Mark all as read error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to mark all as read',
        error: error.message
      });
    }
  };

  /**
   * Delete notification
   * DELETE /api/notifications/:id
   */
  deleteNotification = async (req: Request, res: Response) => {
    try {
      const notificationId = req.params.id;
      const userId = req.body.userId || (req as any).user?.id;

      if (!userId) {
        return res.status(400).json({
          success: false,
          message: 'userId is required'
        });
      }

      const result = await this.service.deleteNotification(notificationId, userId);

      res.status(200).json({
        success: true,
        message: result.message
      });
    } catch (error: any) {
      console.error('Delete notification error:', error);
      res.status(error.message.includes('not found') ? 404 : 500).json({
        success: false,
        message: error.message
      });
    }
  };

  /**
   * Register push subscription (PWA)
   * POST /api/notifications/push-subscription
   */
  registerPushSubscription = async (req: Request, res: Response) => {
    try {
      const { userId, subscription } = req.body;

      if (!userId || !subscription || !subscription.endpoint || !subscription.keys) {
        return res.status(400).json({
          success: false,
          message: 'Invalid subscription data'
        });
      }

      const result = await this.service.registerPushSubscription({ userId, subscription });

      res.status(200).json({
        success: true,
        message: result.message
      });
    } catch (error: any) {
      console.error('Register push subscription error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to register push subscription',
        error: error.message
      });
    }
  };

  /**
   * Unregister push subscription
   * DELETE /api/notifications/push-subscription
   */
  unregisterPushSubscription = async (req: Request, res: Response) => {
    try {
      const { userId, endpoint } = req.body;

      if (!userId || !endpoint) {
        return res.status(400).json({
          success: false,
          message: 'userId and endpoint are required'
        });
      }

      const result = await this.service.unregisterPushSubscription(userId, endpoint);

      res.status(200).json({
        success: true,
        message: result.message
      });
    } catch (error: any) {
      console.error('Unregister push subscription error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to unregister push subscription',
        error: error.message
      });
    }
  };

  /**
   * Send test notification (for debugging)
   * POST /api/notifications/test
   */
  sendTestNotification = async (req: Request, res: Response) => {
    try {
      const { userId, channel } = req.body;

      if (!userId) {
        return res.status(400).json({
          success: false,
          message: 'userId is required'
        });
      }

      const result = await this.service.sendTestNotification(userId, channel);

      res.status(200).json({
        success: true,
        message: result.message
      });
    } catch (error: any) {
      console.error('Send test notification error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to send test notification',
        error: error.message
      });
    }
  };
}