// src/routes/notification.routes.ts
import { Router } from 'express';
import { NotificationController } from '../controllers/notification.controller';

const router = Router();
const controller = new NotificationController();

/**
 * @swagger
 * tags:
 *   name: Notifications
 *   description: Notification management endpoints
 */

/**
 * @swagger
 * /api/notifications/send:
 *   post:
 *     summary: Send notification to a single user
 *     tags: [Notifications]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - recipientId
 *               - type
 *               - data
 *             properties:
 *               recipientId:
 *                 type: string
 *                 format: uuid
 *               type:
 *                 type: string
 *                 enum: [PAYMENT_SUCCESS, MOQ_REACHED, GROUP_CONFIRMED, PRODUCTION_STARTED, SHIPPED, DELIVERED]
 *               data:
 *                 type: object
 *               relatedId:
 *                 type: string
 *                 format: uuid
 *               channels:
 *                 type: array
 *                 items:
 *                   type: string
 *                   enum: [push, whatsapp]
 *     responses:
 *       200:
 *         description: Notification sent successfully
 *       400:
 *         description: Invalid request
 *       500:
 *         description: Server error
 */
router.post('/send', controller.sendNotification);

/**
 * @swagger
 * /api/notifications/send-bulk:
 *   post:
 *     summary: Send notification to multiple users
 *     tags: [Notifications]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - recipients
 *               - type
 *               - data
 *             properties:
 *               recipients:
 *                 type: array
 *                 items:
 *                   type: string
 *                   format: uuid
 *               type:
 *                 type: string
 *               data:
 *                 type: object
 *               relatedId:
 *                 type: string
 *                 format: uuid
 *               channels:
 *                 type: array
 *                 items:
 *                   type: string
 *                   enum: [push, whatsapp]
 *     responses:
 *       200:
 *         description: Bulk notification sent successfully
 */
router.post('/send-bulk', controller.sendBulkNotification);

/**
 * @swagger
 * /api/notifications:
 *   get:
 *     summary: Get user notifications with pagination
 *     tags: [Notifications]
 *     parameters:
 *       - in: query
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *       - in: query
 *         name: type
 *         schema:
 *           type: string
 *       - in: query
 *         name: isRead
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *     responses:
 *       200:
 *         description: List of notifications
 */
router.get('/', controller.getNotifications);

/**
 * @swagger
 * /api/notifications/unread:
 *   get:
 *     summary: Get unread notifications
 *     tags: [Notifications]
 *     parameters:
 *       - in: query
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: List of unread notifications
 */
router.get('/unread', controller.getUnreadNotifications);

/**
 * @swagger
 * /api/notifications/unread-count:
 *   get:
 *     summary: Get unread notification count
 *     tags: [Notifications]
 *     parameters:
 *       - in: query
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Unread count
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     count:
 *                       type: integer
 */
router.get('/unread-count', controller.getUnreadCount);

/**
 * @swagger
 * /api/notifications/{id}/read:
 *   patch:
 *     summary: Mark notification as read
 *     tags: [Notifications]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - userId
 *             properties:
 *               userId:
 *                 type: string
 *                 format: uuid
 *     responses:
 *       200:
 *         description: Notification marked as read
 */
router.patch('/:id/read', controller.markAsRead);

/**
 * @swagger
 * /api/notifications/read-all:
 *   patch:
 *     summary: Mark all notifications as read
 *     tags: [Notifications]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - userId
 *             properties:
 *               userId:
 *                 type: string
 *                 format: uuid
 *     responses:
 *       200:
 *         description: All notifications marked as read
 */
router.patch('/read-all', controller.markAllAsRead);

/**
 * @swagger
 * /api/notifications/{id}:
 *   delete:
 *     summary: Delete notification
 *     tags: [Notifications]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - userId
 *             properties:
 *               userId:
 *                 type: string
 *                 format: uuid
 *     responses:
 *       200:
 *         description: Notification deleted
 */
router.delete('/:id', controller.deleteNotification);

/**
 * @swagger
 * /api/notifications/push-subscription:
 *   post:
 *     summary: Register push notification subscription (PWA)
 *     tags: [Notifications]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - userId
 *               - subscription
 *             properties:
 *               userId:
 *                 type: string
 *                 format: uuid
 *               subscription:
 *                 type: object
 *                 properties:
 *                   endpoint:
 *                     type: string
 *                   keys:
 *                     type: object
 *                     properties:
 *                       p256dh:
 *                         type: string
 *                       auth:
 *                         type: string
 *     responses:
 *       200:
 *         description: Push subscription registered
 */
router.post('/push-subscription', controller.registerPushSubscription);

/**
 * @swagger
 * /api/notifications/push-subscription:
 *   delete:
 *     summary: Unregister push notification subscription
 *     tags: [Notifications]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - userId
 *               - endpoint
 *             properties:
 *               userId:
 *                 type: string
 *                 format: uuid
 *               endpoint:
 *                 type: string
 *     responses:
 *       200:
 *         description: Push subscription unregistered
 */
router.delete('/push-subscription', controller.unregisterPushSubscription);

/**
 * @swagger
 * /api/notifications/test:
 *   post:
 *     summary: Send test notification (for debugging)
 *     tags: [Notifications]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - userId
 *             properties:
 *               userId:
 *                 type: string
 *                 format: uuid
 *               channel:
 *                 type: string
 *                 enum: [push, whatsapp]
 *                 default: push
 *     responses:
 *       200:
 *         description: Test notification sent
 */
router.post('/test', controller.sendTestNotification);

export default router;