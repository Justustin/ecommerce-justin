// src/services/notification.service.ts
import { NotificationRepository } from '../repositories/notification.repository';
import { PushChannel } from '../channels/push.channel';
import { WhatsAppChannel } from '../channels/whatsapp.channel';
import { NotificationTemplates } from '../templates/notification.templates';
import axios from 'axios';
import {
  SendNotificationDTO,
  SendBulkNotificationDTO,
  RegisterPushSubscriptionDTO,
  NotificationFilters,
  PaginatedResponse,
  UserResponseDTO,
  BulkUsersRequestDTO,
  BulkUsersResponseDTO
} from '../types';

export class NotificationService {
  private repository: NotificationRepository;
  private pushChannel: PushChannel;
  private whatsappChannel: WhatsAppChannel;
  private templates: NotificationTemplates;

  constructor() {
    this.repository = new NotificationRepository();
    this.pushChannel = new PushChannel();
    this.whatsappChannel = new WhatsAppChannel();
    this.templates = new NotificationTemplates();
  }

  /**
   * Send notification to a single user
   */
    private async getUserById(userId: string): Promise<UserResponseDTO | null> {
    try {
      const authServiceUrl = process.env.AUTH_SERVICE_URL || 'http://localhost:3001';
      
      const response = await axios.get(`${authServiceUrl}/api/auth/users/${userId}`, {
        headers: { 'Content-Type': 'application/json' }
      });


      if (response.data.success && response.data.user) {
      return response.data.user;
    }
    return null;
    } catch (error) {
      console.error(`Failed to get user ${userId} from AuthService:`, error);
      return null;
    }
  }

    private async getUsersByIds(userIds: string[]): Promise<UserResponseDTO[]> {
    try {
      const authServiceUrl = process.env.AUTH_SERVICE_URL || 'http://localhost:3001';
      
      const response = await axios.post(`${authServiceUrl}/api/auth/users/bulk`, {
        userIds
      }, {
        headers: { 'Content-Type': 'application/json' }
      });

          if (response.data.success && response.data.users) {
      return response.data.users;
    }
    
    console.log('Unexpected bulk response structure:', response.data);
    return [];
    } catch (error) {
      console.error('Failed to get users from AuthService:', error);
      return [];
    }
  }
  async send(data: SendNotificationDTO): Promise<void> {
    try {
      // Get user details from AuthService
      const user = await this.getUserById(data.recipientId);

      if (!user) {
        console.error(`User ${data.recipientId} not found in AuthService`);
        return;
      }

      // 1. Get template data with user info
      const templateData = {
        ...data.data,
        phone_number: user.phoneNumber,
        first_name: user.firstName,
        last_name: user.lastName
      };

      const template = this.templates.getTemplate(data.type, templateData);

      // 2. Create in-app notification
      const notification = await this.repository.create({
        userId: data.recipientId,
        type: data.type,
        title: template.title,
        message: template.message,
        actionUrl: template.actionUrl,
        relatedId: data.relatedId
      });

      // 3. Send via additional channels
      const channels = data.channels || ['whatsapp'];
      const promises: Promise<void>[] = [];

       console.log(`Sending notification via channels: ${channels.join(', ')}`);

      if (channels.includes('push')) {
        promises.push(
          this.pushChannel.send({
            userId: data.recipientId,
            title: template.title,
            message: template.message,
            actionUrl: template.actionUrl,
            icon: template.icon,
            badge: template.badge
          }).then(() => {
            this.repository.markAsPushed(notification.id);
          })
        );
      }

      if (channels.includes('whatsapp')) {
         console.log('Sending via WhatsApp channel');
        promises.push(
          this.whatsappChannel.send({
            userId: data.recipientId,
            phoneNumber: user.phoneNumber, // Phone number from AuthService
            message: template.whatsappMessage
          })
        );
      }

      await Promise.allSettled(promises);

      console.log(`Notification sent: ${data.type} to user ${data.recipientId}, phone: ${user.phoneNumber}`);

    } catch (error) {
      console.error(`Failed to send notification:`, error);
    }
  }
  /**
   * Send notification to multiple users (bulk)
   */
    async sendBulk(data: SendBulkNotificationDTO): Promise<void> {
    try {
      // Get all users' details from AuthService
      const users = await this.getUsersByIds(data.recipients);

      if (users.length === 0) {
        console.log('No users found for bulk notification');
        return;
      }

      const template = this.templates.getTemplate(data.type, data.data);

      // 1. Create in-app notifications
      await this.repository.createBulk(
        users.map(user => ({
          userId: user.userId,
          type: data.type,
          title: template.title,
          message: template.message,
          actionUrl: template.actionUrl,
          relatedId: data.relatedId
        }))
      );

      // 2. Send via other channels
      const channels = data.channels || ['push'];
      const promises: Promise<void>[] = [];

      if (channels.includes('push')) {
        promises.push(
          this.pushChannel.sendBulk({
            userIds: users.map(user => user.userId),
            title: template.title,
            message: template.message,
            actionUrl: template.actionUrl,
            icon: template.icon
          })
        );
      }

      if (channels.includes('whatsapp')) {
        const whatsappPayload = users.map(user => ({
          userId: user.userId,
          phoneNumber: user.phoneNumber, // Phone numbers from AuthService
          message: template.whatsappMessage
        }));

        promises.push(
          this.whatsappChannel.sendBulk({
            messages: whatsappPayload
          })
        );
      }

      await Promise.allSettled(promises);

      console.log(`Bulk notification sent: ${data.type} to ${users.length} users`);

    } catch (error) {
      console.error(`Failed to send bulk notification:`, error);
    }
  }

  /**
   * Get user's notifications with pagination
   */
  async getUserNotifications(filters: NotificationFilters): Promise<PaginatedResponse<any>> {
    return this.repository.findAll(filters);
  }

  /**
   * Get unread notifications for user
   */
  async getUnreadNotifications(userId: string) {
    return this.repository.findByUserId(userId, true);
  }

  /**
   * Mark notification as read
   */
  async markAsRead(notificationId: string, userId: string) {
    const result = await this.repository.markAsRead(notificationId, userId);
    
    if (result.count === 0) {
      throw new Error('Notification not found or unauthorized');
    }

    return { message: 'Notification marked as read' };
  }

  /**
   * Mark all notifications as read
   */
  async markAllAsRead(userId: string) {
    const result = await this.repository.markAllAsRead(userId);
    
    return { 
      message: 'All notifications marked as read',
      count: result.count
    };
  }

  /**
   * Get unread count
   */
  async getUnreadCount(userId: string): Promise<{ count: number }> {
    const count = await this.repository.getUnreadCount(userId);
    return { count };
  }

  /**
   * Delete notification
   */
  async deleteNotification(notificationId: string, userId: string) {
    const result = await this.repository.delete(notificationId, userId);
    
    if (result.count === 0) {
      throw new Error('Notification not found or unauthorized');
    }

    return { message: 'Notification deleted successfully' };
  }

  /**
   * Register push subscription for a user (PWA)
   */
  async registerPushSubscription(data: RegisterPushSubscriptionDTO) {
    await this.pushChannel.registerSubscription(data.userId, data.subscription);
    return { message: 'Push subscription registered successfully' };
  }

  /**
   * Unregister push subscription
   */
  async unregisterPushSubscription(userId: string, endpoint: string) {
    await this.pushChannel.unregisterSubscription(userId, endpoint);
    return { message: 'Push subscription unregistered successfully' };
  }

  /**
   * Test notification (for debugging)
   */
  async sendTestNotification(userId: string, channel: 'push' | 'whatsapp' = 'push') {
    await this.send({
      recipientId: userId,
      type: 'PAYMENT_SUCCESS' as any,
      data: {
        amount: 150000,
        productName: 'Test Product',
        invoiceId: 'INV-TEST-12345',
        orderId: 'test-order-id'
      },
      channels: [channel]
    });

    return { message: `Test ${channel} notification sent to user ${userId}` };
  }
}