import { OrderRepository } from '../repositories/order.repository';
import { OrderUtils } from '../utils/order.utils';
import axios, { AxiosError } from 'axios';

import {
  CreateOrderDTO,
  UpdateOrderStatusDTO,
  CreateBulkOrdersDTO,
  OrderFilters,
  PaginatedResponse,
  CreatePaymentDTO,
  ShippingRateOption,
  CalculateShippingDTO,
  CreateShipmentDTO,
  ShipmentData,
  UpdateOrderStatusFromLogisticsDTO

} from '../types';
import { NotificationService } from '../../../notification-service/src/services/notification.service';
const WAREHOUSE_HANDLING_FEE = 5000;
const TRANSACTION_FEE_RATE = 0.02;
const notificationServiceUrl = process.env.NOTIFICATION_SERVICE_URL || 'http://localhost:3007';
const logisticsServiceUrl = process.env.LOGISTIC_SERVICE_URL || 'http://localhost:3008';
const factoryServiceUrl = process.env.FACTORY_SERVICE_URL || 'http://localhost:3003';

export class OrderService {
  private repository: OrderRepository;
  private utils: OrderUtils;

  constructor() {
    this.repository = new OrderRepository();
    this.utils = new OrderUtils();
  }

  async createOrder(data: CreateOrderDTO) {
    // Validation
    if (!data.items || data.items.length === 0) {
      throw new Error('Order must have at least one item');
    }

    if (!data.shippingAddress.name || !data.shippingAddress.address) {
      throw new Error('Complete shipping address required');
    }

    // Build order items with pricing and snapshots
    const enrichedItems = await Promise.all(
      data.items.map(async (item) => {
        const price = await this.utils.getProductPrice(item.productId, item.variantId);
        const factoryId = await this.utils.getProductFactoryId(item.productId);
        const snapshot = await this.utils.buildProductSnapshot(item.productId, item.variantId);

        return {
          productId: item.productId,
          variantId: item.variantId,
          factoryId,
          quantity: item.quantity,
          unitPrice: price,
          subtotal: price * item.quantity,
          sku: snapshot.product.sku,
          productName: snapshot.product.name,
          variantName: snapshot.variant?.variant_name,
          productSnapshot: snapshot
        };
      })
    );

    // Group items by factory
    const factoryGroups = new Map<string, any[]>();
    enrichedItems.forEach(item => {
      const existing = factoryGroups.get(item.factoryId) || [];
      existing.push(item);
      factoryGroups.set(item.factoryId, existing);
    });

    // Generate base order number
    const orderNumber = this.utils.generateOrderNumber();

    // Create separate orders per factory
    const orders = await this.repository.createOrder(
      {
        ...data,
        selectedCourier: data.selectedCourier,
        selectedCourierService: data.selectedCourierService,
        shippingCost: data.shippingCost || 0
      },
      orderNumber,
      factoryGroups
    );

    const paymentServiceUrl = process.env.PAYMENT_SERVICE_URL

    const payments = await Promise.all(
    orders.map(async (order: any) => {
      // Validate order_items exists (from repository include)
      if (!order.order_items || order.order_items.length === 0) {
        console.error(`No order_items found for order ${order.id}`);
        throw new Error(`Cannot create payment: No items for order ${order.id}`);
      }

      // Use pre-calculated total_amount from repository (includes discounts)
      const totalAmount = Number(order.total_amount || 0); // Convert Decimal to number if needed

      // Get factory_id from first order_item (all share the same factory)
      const factoryId = order.order_items[0].factory_id;

      const paymentData: CreatePaymentDTO = {
        orderId: order.id,
        userId: data.userId,
        amount: totalAmount,
        totalAmount: totalAmount,
        paymentMethod: "bank_transfer",
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
        isEscrow: !!order.group_session_id, // Set isEscrow for group buying orders
      };

      try {
        console.log(`Calling PaymentService for order ${order.id} with amount ${totalAmount} and factory_id ${factoryId}`);
        const response = await axios.post(`${paymentServiceUrl}/api/payments`, paymentData, {
          headers: {
            'Content-Type': 'application/json',
            // 'Authorization': `Bearer ${process.env.PAYMENT_SERVICE_API_KEY}`
          }
        });
        return response.data; // Expected: { payment, paymentUrl, invoiceId }
      } catch (error: any) {
        console.error(`Failed to create payment for order ${order.id}:`, error.message);
        throw new Error(`Payment creation failed: ${error.response?.data?.message || error.message}`);
      }
    })
  );
  
  for (const order of orders) {
    try {
      const orderWithItems = order as any;
      const factoryId = orderWithItems.order_items?.[0]?.factory_id;
      if (!factoryId) {
      console.warn(`Order ${orderWithItems.id} has no factory_id, skipping notification`);
      continue;
    }
    
    const factory = await this.getFactoryDetails(factoryId);

    await axios.post(`${notificationServiceUrl}/api/notifications/send`, {
      recipientId: data.userId,
      type: 'order_created',
      data: {
        orderNumber: orderWithItems.order_number,
        totalAmount: Number(orderWithItems.total_amount), // ✅ Convert to number
        orderId: orderWithItems.id,
        factoryName: factory?.factory_name || 'Pabrik',
        productName: orderWithItems.order_items?.[0]?.product_name || 'Produk',
        quantity: orderWithItems.order_items?.reduce((sum: number, item: any) => sum + item.quantity, 0) || 0,
        shippingCost: Number(orderWithItems.shipping_cost || 0),
        subtotal: Number(orderWithItems.subtotal || 0)
      },
      relatedId: orderWithItems.id,
      channels: ['whatsapp']
    });
  } catch (error) {
    console.error('Failed to send order notification:', error);
  }
}


    return {
      success: true,
      payments: payments,
      ordersCreated: orders.length,
      orders,
      message: factoryGroups.size > 1 
        ? `Created ${orders.length} orders (items from ${factoryGroups.size} factories)`
        : 'Order created successfully'
    };
  }

  async createBulkOrdersFromSession(data: CreateBulkOrdersDTO) {
    if (!data.participants || data.participants.length === 0) {
      throw new Error('No participants to create orders for');
    }

    const orders = await this.repository.createBulkOrders(data);

    return {
      success: true,
      ordersCreated: orders.length,
      orders
    };
  }

  async getOrder(id: string) {
    const order = await this.repository.findById(id);
    if (!order) {
      throw new Error('Order not found');
    }
    return order;
  }

  async getOrderByNumber(orderNumber: string) {
    const order = await this.repository.findByOrderNumber(orderNumber);
    if (!order) {
      throw new Error('Order not found');
    }
    return order;
  }

  async getOrders(filters: OrderFilters): Promise<PaginatedResponse<any>> {
    return this.repository.findAll(filters);
  }

  async updateOrderStatus(data: UpdateOrderStatusDTO) {
  const orderResult = await this.repository.findById(data.orderId);
  if (!orderResult) {
    throw new Error('Order not found');
  }

  const order = orderResult as any;

  const validTransitions: Record<string, string[]> = {
    pending_payment: ['paid', 'failed', 'cancelled'],
    paid: ['processing', 'refunded', 'cancelled'],
    processing: ['ready_for_pickup', 'cancelled'],
    ready_for_pickup: ['picked_up', 'cancelled'],
    picked_up: ['in_transit'],
    in_transit: ['delivered', 'failed'],
    delivered: ['refunded'],
    cancelled: ['refunded'],
    refunded: [],
    failed: ['pending_payment']
  };

  const currentStatus = order.status;
  const allowed = validTransitions[currentStatus] || [];

  if (!allowed.includes(data.newStatus)) {
    throw new Error(
      `Cannot transition from ${currentStatus} to ${data.newStatus}`
    );
  }

  //Auto-create shipment for ready_for_pickup
  if (data.newStatus === 'ready_for_pickup') {
    try {
      const courier = order.selected_courier || 'jne';
      const courierService = order.selected_courier_service || 'reg';
      
      await this.createShipmentAfterPayment(
        data.orderId,
        courier,
        courierService
      );
      console.log(`✅ Auto-created shipment for order ${order.order_number}`);
    } catch (error: any) {
      console.error('❌ Failed to auto-create shipment:', error.message);
    }
  }

  const result = await this.repository.updateStatus(data);

  try {
    const factoryId = order.order_items?.[0]?.factory_id;
    const factory = factoryId ? await this.getFactoryDetails(factoryId) : null;
    const productName = order.order_items?.[0]?.product_name || 'Produk';

    // Payment Success
    if (data.newStatus === 'paid') {
      await axios.post(`${notificationServiceUrl}/api/notifications/send`, {
        recipientId: order.user_id,
        type: 'payment_success',
        data: {
          orderNumber: order.order_number,
          paymentAmount: Number(order.total_amount),
          productName: productName,
          invoiceId: 'Processing',
          orderId: order.id
        },
        relatedId: order.id,
        channels: ['whatsapp']
      });
    }

    // Processing Started
    if (data.newStatus === 'processing') {
      await axios.post(`${notificationServiceUrl}/api/notifications/send`, {
        recipientId: order.user_id,
        type: 'production_started',
        data: {
          orderNumber: order.order_number,
          productName: productName,
          factoryName: factory?.factory_name || 'Pabrik',
          estimatedDelivery: this.calculateEstimatedDelivery(3),
          orderId: order.id
        },
        relatedId: order.id,
        channels: ['whatsapp']
      });
    }

    // Ready for Pickup (by courier)
    if (data.newStatus === 'ready_for_pickup') {
      await axios.post(`${notificationServiceUrl}/api/notifications/send`, {
        recipientId: order.user_id,
        type: 'ready_for_pickup',
        data: {
          orderNumber: order.order_number,
          productName: productName,
          factoryName: factory?.factory_name || 'Pabrik',
          courierName: this.getCourierDisplayName(order.selected_courier || 'jne'),
          orderId: order.id
        },
        relatedId: order.id,
        channels: ['whatsapp']
      });
    }

    // Picked Up by Courier
    if (data.newStatus === 'picked_up') {
      let trackingNumber = 'N/A';
      let trackingUrl = '';
      
      try {
        const tracking = await axios.get(`${logisticsServiceUrl}/api/shipments/order/${data.orderId}`);
        const shipment = tracking.data.data;
        trackingNumber = shipment.tracking_number;
        trackingUrl = shipment.courier_api_response?.courier?.link || '';
      } catch (error) {
        console.error('Failed to get tracking info:', error);
      }

      await axios.post(`${notificationServiceUrl}/api/notifications/send`, {
        recipientId: order.user_id,
        type: 'picked_up',
        data: {
          orderNumber: order.order_number,
          productName: productName,
          courierName: this.getCourierDisplayName(order.selected_courier || 'courier'),
          trackingNumber: trackingNumber,
          trackingUrl: trackingUrl,
          estimatedDelivery: this.calculateEstimatedDelivery(2),
          orderId: order.id
        },
        relatedId: order.id,
        channels: ['whatsapp']
      });
    }

    // In Transit
    if (data.newStatus === 'in_transit') {
      let trackingNumber = 'N/A';
      let trackingUrl = '';
      
      try {
        const tracking = await axios.get(`${logisticsServiceUrl}/api/shipments/order/${data.orderId}`);
        const shipment = tracking.data.data;
        trackingNumber = shipment.tracking_number;
        trackingUrl = shipment.courier_api_response?.courier?.link || '';
      } catch (error) {
        console.error('Failed to get tracking info:', error);
      }

      await axios.post(`${notificationServiceUrl}/api/notifications/send`, {
        recipientId: order.user_id,
        type: 'shipped',
        data: {
          orderNumber: order.order_number,
          productName: productName,
          courierName: this.getCourierDisplayName(order.selected_courier || 'courier'),
          trackingNumber: trackingNumber,
          trackingUrl: trackingUrl,
          estimatedDelivery: this.calculateEstimatedDelivery(1),
          orderId: order.id
        },
        relatedId: order.id,
        channels: ['whatsapp']
      });
    }

    // Delivered
    if (data.newStatus === 'delivered') {
      const now = new Date();
      const deliveryTime = now.toLocaleString('id-ID', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });

      await axios.post(`${notificationServiceUrl}/api/notifications/send`, {
        recipientId: order.user_id,
        type: 'delivered',
        data: {
          orderNumber: order.order_number,
          productName: productName,
          receivedBy: order.shipping_name,
          deliveryTime: deliveryTime,
          orderId: order.id
        },
        relatedId: order.id,
        channels: ['whatsapp']
      });
    }

    // Cancelled
    if (data.newStatus === 'cancelled') {
      await axios.post(`${notificationServiceUrl}/api/notifications/send`, {
        recipientId: order.user_id,
        type: 'order_cancelled',
        data: {
          orderNumber: order.order_number,
          reason: 'Permintaan pelanggan',
          orderId: order.id
        },
        relatedId: order.id,
        channels: ['whatsapp']
      });
    }

  } catch (error: any) {
    console.error('Failed to send status notification:', error.message);
  }

  return result;
}

  async updateShippingCost(orderId: string, shippingCost: number, taxAmount: number = 0) {
    if (shippingCost < 0) {
      throw new Error('Shipping cost cannot be negative');
    }
    return this.repository.updateShippingCost(orderId, shippingCost, taxAmount);
  }

  async cancelOrder(orderId: string, userId?: string) {
    const order = await this.repository.findById(orderId);
    if (!order) {
      throw new Error('Order not found');
    }

    // Only user or admin can cancel
    if (userId && order.user_id !== userId) {
      // TODO: Check if userId is admin
      throw new Error('Unauthorized to cancel this order');
    }

    return this.repository.cancelOrder(orderId, userId);
  }

  async getOrderStats(filters: Partial<OrderFilters>) {
    return this.repository.getOrderStats(filters);
  }

  async getUserOrders(userId: string, page = 1, limit = 20) {
    return this.repository.findAll({
      userId,
      page,
      limit
    });
  }

  async getFactoryOrders(factoryId: string, page = 1, limit = 20) {
    return this.repository.findAll({
      factoryId,
      page,
      limit
    });
  }

  private async getFactoryAddress(orderId: string) {
  try {
    const order = await this.repository.findById(orderId);
    if (!order || !order.order_items || order.order_items.length === 0) {
      throw new Error('Order has no items');
    }

    const factoryId = order.order_items[0].factory_id;
    
    console.log(`📍 Fetching factory address for factory: ${factoryId}`);
    
    const response = await axios.get(
      `${factoryServiceUrl}/api/factories/${factoryId}`
    );
    
    const factory = response.data.data;
    
    return {
      name: factory.factory_name || 'Factory',
      phone: factory.phone_number || '+6281234567890',
      address: factory.address_line || 'Jakarta',
      city: factory.city || 'Jakarta',
      province: factory.province || 'DKI Jakarta',
      postalCode: parseInt(factory.postal_code || '10000'),
      latitude: factory.latitude,
      longitude: factory.longitude
    };
  } catch (error: any) {
    console.error('❌ Failed to fetch factory address:', error.message);
    return {
      name: 'Laku Warehouse',
      phone: '+6281234567890',
      address: 'Jl. Sudirman No. 100, Jakarta Pusat',
      city: 'Jakarta Pusat',
      province: 'DKI Jakarta',
      postalCode: 13910
    };
  }
}



async calculateShippingRates(data: CalculateShippingDTO): Promise<ShippingRateOption[]> {
  try {
    let originPostalCode = 13910;
    
    if (data.orderId) {
      const factoryAddress = await this.getFactoryAddress(data.orderId);
      originPostalCode = factoryAddress.postalCode;
    }else if (data.items && data.items.length > 0) {
      //Get factory from product during checkout
      try {
        const productId = data.items[0].productId;
        const factoryId = await this.utils.getProductFactoryId(productId);
        
        const response = await axios.get(
          `${factoryServiceUrl}/api/factories/${factoryId}`
        );
        
        originPostalCode = parseInt(response.data.data.postal_code || '13910');
        console.log(`📍 Using factory postal code: ${originPostalCode}`);
      } catch (error) {
        console.warn('Could not fetch factory postal code, using default');
      }
    }
    console.log('📦 Calling Logistics Service for rates...');

    const response = await axios.post(`${logisticsServiceUrl}/api/rates`, {
      orderId: data.orderId,
      originPostalCode,
      destinationPostalCode: parseInt(data.destinationPostalCode),
      couriers: 'jne,jnt,sicepat,anteraja'
    });

    console.log('✅ Logistics response:', JSON.stringify(response.data, null, 2));

    const pricing = response.data.data?.pricing || response.data.pricing || [];
    
    console.log('📊 Found rates:', pricing.length);

    return pricing;
  } catch (error: any) {
    console.error('❌ Failed to calculate shipping rates:', error.message);
    throw new Error(`Shipping calculation failed: ${error.response?.data?.message || error.message}`);
  }
}

// 3. Create shipment after payment
async createShipmentAfterPayment(
  orderId: string, 
  courierCompany?: string, 
  courierType?: string
) {
  try {
    const order = await this.repository.findById(orderId);
    if (!order) throw new Error('Order not found');

    const factoryAddress = await this.getFactoryAddress(orderId);
    const selectedCourier = courierCompany || 'jne';
    const selectedType = courierType || 'reg';

    console.log(`📦 Creating shipment from ${factoryAddress.name} (${factoryAddress.city}) to ${order.shipping_name}`);

    const shipmentData = {
      orderId: order.id,
      courierCompany: selectedCourier,
      courierType: selectedType,
      
      shipperContactName: factoryAddress.name,
      shipperContactPhone: factoryAddress.phone,
      originContactName: `${factoryAddress.name} Team`,
      originContactPhone: factoryAddress.phone,
      originAddress: factoryAddress.address,
      originPostalCode: factoryAddress.postalCode,
      originLatitude: factoryAddress.latitude,
      originLongitude: factoryAddress.longitude,
      
      destinationContactName: order.shipping_name,
      destinationContactPhone: order.shipping_phone,
      destinationAddress: order.shipping_address,
      destinationPostalCode: parseInt(order.shipping_postal_code || '10000'),
      destinationNote: order.shipping_notes,
      
      deliveryType: 'now',
      items: []
    };

    const response = await axios.post(
      `${logisticsServiceUrl}/api/shipments`,
      shipmentData
    );

    console.log(`✅ Shipment created: ${response.data.shipment.tracking_number}`);
    const trackingNumber = response.data?.shipment?.tracking_number 
      || response.data?.data?.tracking_number
      || 'N/A';
    console.log(`✅ Shipment created: ${trackingNumber}`);
    return response.data;
  } catch (error: any) {
    console.error('Failed to create shipment:', error.message);
    throw new Error(`Shipment creation failed: ${error.response?.data?.message || error.message}`);
  }
}

  // 4. Update order status from logistics
  async updateOrderStatusFromLogistics(data: UpdateOrderStatusFromLogisticsDTO) {
    const order = await this.repository.findById(data.orderId);
    if (!order) throw new Error('Order not found');

    await this.updateOrderStatus({
      orderId: data.orderId,
      newStatus: data.newStatus as any
    });

    return {
      success: true,
      message: 'Order status updated from logistics',
      orderId: data.orderId,
      newStatus: data.newStatus
    };
  }

  // 5. Get order tracking
  async getOrderTracking(orderId: string) {
    try {
      const response = await axios.get(
        `${logisticsServiceUrl}/api/shipments/order/${orderId}`
      );
      return response.data;
    } catch (error: any) {
      if (error.response?.status === 404) {
        return null;
      }
      throw new Error(`Failed to get tracking: ${error.message}`);
    }
  }
  private getCourierDisplayName(courierCode: string): string {
  const courierNames: Record<string, string> = {
    'jnt': 'J&T Express',
    'jne': 'JNE',
    'sicepat': 'SiCepat',
    'anteraja': 'AnterAja',
    'gojek': 'GoSend'
  };
  return courierNames[courierCode] || courierCode.toUpperCase();
  }

  private calculateEstimatedDelivery(daysToAdd: number): string {
    const date = new Date();
    date.setDate(date.getDate() + daysToAdd);
    return date.toLocaleDateString('id-ID', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  }

  private async getFactoryDetails(factoryId: string) {
    try {
      const response = await axios.get(`${factoryServiceUrl}/api/factories/${factoryId}`);
      return response.data.data;
    } catch (error) {
      console.error('Failed to fetch factory details:', error);
      return null;
    }
  }

}